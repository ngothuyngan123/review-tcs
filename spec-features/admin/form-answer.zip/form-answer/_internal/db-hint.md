# DB Hint — FA-011 フォーム作成

> File nội bộ — cầu nối giữa UI spec và DB mapping.
> Dùng bởi db-mapper agent để tìm bảng liên quan.

---

## SCR-FA11-01: Danh sách form

### Table Columns → Data hints

| Tiêu đề JP | Dữ liệu mẫu | Kiểu dữ liệu dự đoán | Tên cột DB dự đoán |
|-----------|-------------|---------------------|-------------------|
| 「管理名」 | "test chẩn đoán", "rẽ nhánh 100" | VARCHAR(50) | `name` hoặc `manage_name` |
| 「タイプ」 | シンプル / 分岐 | TINYINT hoặc VARCHAR ENUM | `type` (0=simple, 1=branch) |
| 「作成日」 | 2026.04.16 | DATETIME → DATE | `created_at` |
| 「最終編集日」 | 2026.05.08 | DATETIME → DATE | `updated_at` |
| 「公開状態」 | ON/OFF toggle | TINYINT(1) | `is_public` hoặc `status` |
| 「クイックテスト」 | "クイックテスト未登録" / đã đăng ký | INT FK → quick test table | `quick_test_id` (nullable) |
| 「回答情報」 | 1人 / 0人 | COUNT từ bảng answer | JOIN từ answers table |

### URL patterns → ID/Slug hints

| URL | Thông tin |
|-----|---------|
| `/basic/form-answer/v3/result/{id}` | ID là integer (vd: 124593, 124299, 124218, 124217, 124216) |
| `/basic/form-answer/form-render/{slug}?mode=preview` | Slug là chuỗi random 6 ký tự (vd: Nm6wtb, rZ4OJO, EeDVFW) |
| `/ajax/download-answer/{id}` | Cùng ID với result page |
| Google Sheets URL | Lưu spreadsheet_id |

### Enum/Status values

| Hiển thị JP | Giá trị DB dự đoán |
|------------|-------------------|
| 「シンプル」 | `0` hoặc `'simple'` |
| 「分岐」 | `1` hoặc `'branch'` |

### Action outcomes

| Hành động | Thay đổi DB dự kiến |
|---------|-------------------|
| Chuyển thư mục form | UPDATE `folder_id` trong bảng form |
| Soft-delete form | UPDATE `deleted_at` = NOW() (hoặc `status = deleted`) |
| Toggle公開状態 | UPDATE `is_public`/`status` |
| Kết nối Google Sheets | INSERT/UPDATE vào bảng setting liên kết |

---

## SCR-FA11-02: Modal tạo form mới

### Form Fields → DB columns

| Label JP | Giá trị mẫu | Kiểu dữ liệu | Bắt buộc | Tên cột DB dự đoán |
|---------|------------|------------|---------|-------------------|
| 「管理名」 | (text, ≤50 chars) | VARCHAR(50) | Có | `name` hoặc `manage_name` |
| 「フォーム名」 | (text, ≤20 chars) | VARCHAR(20) | Có | `form_name` hoặc `title` |
| 「フォルダ」 | "未分類", folder names | INT FK | Không | `folder_id` (0 = 未分類) |
| 「タイプ」 | シンプル / 分岐 | TINYINT/ENUM | Có | `type` |
| Lựa chọn nhanh (名前, etc.) | ON/OFF checkboxes | — | Không | Dùng để tạo items ban đầu |

### Quan sát tạo ban đầu

- Khi tạo form, hệ thống sẽ INSERT record vào bảng form chính
- Nếu chọn「よく使われる項目」, hệ thống cũng INSERT các item câu hỏi mặc định
- `type` không thể đổi sau khi tạo → constraint hoặc logic ở code

---

## SCR-FA11-03: Form Editor — Tab フォーム編集

### Form structure (canvas items)

Mỗi item trong form là 1 record trong bảng items:

| Thuộc tính | Giá trị mẫu | Kiểu dữ liệu | Tên cột DB dự đoán |
|-----------|------------|------------|-------------------|
| Loại item | 短文回答, 長文回答, 単一選択, 複数選択, ファイルアップロード, 診断コンテンツ, リマインド, 規約の同意, 見出し, テキスト, 画像, 動画埋め込み, 区切り線, カスタムHTML | ENUM/TINYINT | `type` hoặc `item_type` |
| 質問文 | "test", "chan doan" | TEXT/VARCHAR(50) | `question` hoặc `label` |
| Bắt buộc/Tùy chọn | 必須 / 任意 | TINYINT(1) | `is_required` |
| 補足 | (text, ≤200 chars) | VARCHAR(200) | `description` |
| プレースホルダ | (text, ≤50 chars) | VARCHAR(50) | `placeholder` |
| 入力制限 | 制限しない / 制限する | TINYINT(1) | `input_limit` |
| 友だち情報記録 | 記録しない / 記録する | TINYINT(1) | `record_friend_info` |
| Liên kết 友だち情報 | ID của friend info field | INT FK | `friend_information_id` (nullable) |
| CSSクラス (質問文) | (text) | VARCHAR | `css_class_question` |
| CSSクラス (補足) | (text) | VARCHAR | `css_class_supplement` |
| Thứ tự | Drag-drop order | INT | `sort_order` hoặc `position` |

### Bảng item type dự đoán

| Loại item | Loại | Cần thêm bảng options? |
|----------|------|----------------------|
| 短文回答 | question | Không |
| 長文回答 | question | Không |
| 日付・時刻 | question | Không |
| 単一選択 | question | Có (bảng choices) |
| 複数選択 | question | Có (bảng choices) |
| ファイルアップロード | question | Không |
| 診断コンテンツ | question (scoring) | Có (điểm cho từng lựa chọn) |
| リマインド | question | Có (cài đặt nhắc lịch) |
| 規約の同意 | question | Có (URL điều khoản) |
| 名前 | question (preset) | Không (dùng cấu hình có sẵn) |
| 見出し | decoration | Không |
| テキスト | decoration | Không |
| 画像 | decoration | Có (image URL) |
| 動画埋め込み | decoration | Có (video URL) |
| 区切り線 | decoration | Không |
| カスタムHTML | decoration | Có (HTML content) |

### Header image

| Thuộc tính | Kiểu dữ liệu | Tên cột DB dự đoán |
|-----------|------------|-------------------|
| Ảnh header | VARCHAR/TEXT (path hoặc URL) | `header_image` |

### Nút submit

| Thuộc tính | Giá trị mẫu | Kiểu dữ liệu | Tên cột DB dự đoán |
|-----------|------------|------------|-------------------|
| Text nút submit | 「回答する」 | VARCHAR | `submit_button_text` |

---

## SCR-FA11-04: Tab 共通デザイン設定

### Form Fields → DB columns

| Label JP | Giá trị mẫu | Kiểu dữ liệu | Bắt buộc | Tên cột DB dự đoán |
|---------|------------|------------|---------|-------------------|
| 「共通ヘッダー画像」 | PNG/JPG, 1000×400px | VARCHAR (file path/URL) | Không | `header_image_path` |
| 「フォーム背景カラー」 | `#FFFFFF` | VARCHAR(7) | Không | `bg_color` |
| 「見出し」デザイン | (CSS settings) | JSON/VARCHAR | Không | `design_heading` |
| 「区切り線」デザイン | (CSS settings) | JSON/VARCHAR | Không | `design_divider` |
| 「質問項目」デザイン | (CSS settings) | JSON/VARCHAR | Không | `design_question` |
| 「ボタン」デザイン | (CSS settings) | JSON/VARCHAR | Không | `design_button` |
| 「CSS・JS設定」 | Custom CSS/JS | TEXT | Không | `custom_css`, `custom_js` |

**Dự đoán**: Các setting thiết kế có thể được lưu dưới dạng JSON trong cột `design_settings` hoặc tách thành nhiều cột — **Trung bình**

---

## SCR-FA11-05: Tab メッセージ・アクション設定

### Form Fields → DB columns

| Label JP | Giá trị mẫu | Kiểu dữ liệu | Bắt buộc | Tên cột DB dự đoán |
|---------|------------|------------|---------|-------------------|
| 「アクションの稼働回数」 | 何度でも / 1度のみ | TINYINT(1) | Có | `action_repeat` (0=unlimited, 1=once) |
| 「回答完了時に送信するメッセージ」 | Text with variables, ≤5000 | TEXT | Không | `submit_message` |
| 「質問と回答のコピーメッセージを送る」 | ON/OFF | TINYINT(1) | Không | `send_qa_copy` |
| 「回答完了時アクション」 | Action settings (SC-004) | FK → t_actions | Không | `action_id` |
| 「フォーム表示時アクション」 | Action settings (SC-004) | FK → t_actions | Không | `open_action_id` |
| 「リマインドメッセージ」 | (Reminder settings) | FK / JSON | Không | (chưa rõ) |

### Variables trong tin nhắn

| Variable | Ý nghĩa |
|---------|--------|
| `{name}` | Tên LINE của người dùng (LINE名) |
| 「友だち情報」 | Các trường thông tin bạn bè tùy chỉnh |

---

## SCR-FA11-06: Tab 診断コンテンツ

### Form Fields → DB columns

| Label JP | Giá trị mẫu | Kiểu dữ liệu | Bắt buộc | Tên cột DB dự đoán |
|---------|------------|------------|---------|-------------------|
| 「作成しない/作成する」 | ON/OFF | TINYINT(1) | Có | `has_diagnostic` |
| 「ポイントを記録する友だち情報」 | ID của Point-type field | INT FK | Có (khi bật) | `diagnostic_point_field_id` |

### Cơ chế chẩn đoán (scoring)

- Item loại「診断コンテンツ」trong form sẽ có các lựa chọn, mỗi lựa chọn có điểm số
- Điểm tổng = tổng điểm của các câu trả lời
- Điểm lưu vào field「友だち情報」loại Point

### Table hints

- Bảng choices/options có thể thêm cột `diagnostic_point` cho từng lựa chọn
- Kết quả chẩn đoán hiển thị trong SCR-FA11-09: `診断ポイント: 2 ポイント`

---

## SCR-FA11-07: Tab 各種設定

### Form Fields → DB columns

| Label JP | Giá trị mẫu | Kiểu dữ liệu | Bắt buộc | Tên cột DB dự đoán |
|---------|------------|------------|---------|-------------------|
| 「回答確認ページ」 | 表示しない / 表示する | TINYINT(1) | Có | `show_confirm_page` |
| 「回答後ページ」 | 回答後ページを表示しない / 表示する | TINYINT(1) | Có | `show_thanks_page` |
| 「回答制限」 | (giới hạn số lần trả lời / IP) | TINYINT/INT | Không | `answer_limit` (chưa rõ cấu trúc) |
| 「表示期限」 | (datetime range) | DATETIME | Không | `display_from`, `display_until` |
| 「カウントダウンタイマー」 | ON/OFF + datetime | TINYINT + DATETIME | Không | `countdown_enabled`, `countdown_target` |
| 「LINEトーク画面・フォーム名表示」 | ON/OFF | TINYINT(1) | Không | `show_form_name_in_chat` |

---

## SCR-FA11-08: Form công khai

### URL → DB mapping

- Slug (`Nm6wtb`) → cột `slug` trong bảng form chính
- Form hiển thị items theo `sort_order`
- Submit → INSERT vào bảng answers

### Action sau submit

- Gửi tin nhắn `submit_message` (qua LINE Messaging API)
- Kích hoạt action `action_id` (SC-004)
- Lưu điểm chẩn đoán vào friend info field

---

## SCR-FA11-09: Trang kết quả — 回答一覧

### Table Columns → DB columns

| Tiêu đề JP | Dữ liệu mẫu | Kiểu dữ liệu | Tên cột DB dự đoán |
|-----------|------------|------------|-------------------|
| 「回答日時」 | 2026.05.08(金) 11:34 | DATETIME | `created_at` hoặc `submitted_at` |
| 「回答時間」 | 00分09秒 | INT (seconds) | `answer_duration` hoặc `time_spent` |
| 「友だち名」 | テスト'T/Thanh | VARCHAR (LINE display name) | FK → line_users |
| 「診断ポイント」 | 2 ポイント | INT | SUM of diagnostic points |

### Panel chi tiết câu trả lời

| Thành phần | Kiểu dữ liệu | Tên cột DB dự đoán |
|-----------|------------|-------------------|
| Câu trả lời từng câu hỏi | TEXT/VARCHAR | `answer` trong bảng answer_details |
| Link bạn bè `/basic/friendlist/my_page/{id}` | INT | FK → line_users.id |
| Tab「リマインド」| — | Bảng riêng liên kết answer + reminder |

### Action outcomes

| Hành động | Thay đổi DB dự kiến |
|---------|-------------------|
| 「この回答を削除」 | DELETE hoặc soft-delete record trong bảng answers |
| Filter theo ngày | Query với WHERE submitted_at BETWEEN start AND end |
| Download CSV | SELECT * từ bảng answers + answer_details |

---

## SCR-FA11-10: Form đã xóa — 削除済みフォーム

### Table Columns → DB columns

| Tiêu đề JP | Dữ liệu mẫu | Kiểu dữ liệu | Tên cột DB dự đoán |
|-----------|------------|------------|-------------------|
| 「削除した日時」 | 2026.03.19(木) 18:15 | DATETIME | `deleted_at` |
| 「フォーム名」 | "form basi...", "basic 1" | VARCHAR (truncated in UI) | `name` hoặc `manage_name` |
| 「削除したユーザー名」 | 田中 太郎 | VARCHAR | FK → users.name |

### Action outcomes

| Hành động | Thay đổi DB dự kiến |
|---------|-------------------|
| 「復元する」 | UPDATE `deleted_at` = NULL (soft-delete restore) |
| Tự động xóa sau 90 ngày | Cron job DELETE WHERE deleted_at < NOW() - 90 days |

---

## Dự đoán cấu trúc bảng DB

### Bảng chính

| Bảng DB | Vai trò | Cột quan trọng |
|---------|--------|---------------|
| `form_answers` (hoặc `forms`) | Bảng form chính | `id`, `bot_id` (FK → bots), `name`, `form_name`, `slug`, `type` (0=simple, 1=branch), `folder_id`, `is_public`, `deleted_at`, `created_at`, `updated_at` |
| `form_answer_items` (hoặc `form_items`) | Các câu hỏi/item trong form | `id`, `form_id` (FK), `type`, `label`, `is_required`, `sort_order`, `description`, `placeholder`, `input_limit`, `record_friend_info`, `friend_information_id`, `css_class_question`, `css_class_supplement` |
| `form_answer_item_options` | Các lựa chọn cho câu hỏi dạng select | `id`, `item_id` (FK), `label`, `value`, `sort_order`, `diagnostic_point` |
| `form_answer_results` (hoặc `form_answers_results`) | Bảng lưu từng submission | `id`, `form_id` (FK), `line_user_id` (FK), `submitted_at`, `time_spent` |
| `form_answer_details` | Chi tiết từng câu trả lời | `id`, `result_id` (FK), `item_id` (FK), `answer` (TEXT) |
| `form_answer_folders` (hoặc folders dùng chung) | Thư mục | `id`, `bot_id`, `name`, `sort_order` |

### Bảng liên kết / cài đặt

| Bảng DB | Vai trò |
|---------|--------|
| `form_answer_settings` (hoặc trong cột JSON của form) | Lưu design settings, message settings, các cài đặt khác |
| `form_answer_google_sheets` | Liên kết Google Sheets (spreadsheet_id, form_id) |

### Bảng liên quan ngoài tính năng

| Bảng | Quan hệ |
|------|--------|
| `bots` | FK parent — mỗi form thuộc 1 bot (LINE OA) |
| `line_users` | FK trong results — người submit |
| `friend_information_setting` | FK — câu hỏi liên kết với custom friend info field |
| `t_actions` | FK — action sau submit (SC-004) |
| `t_actions_detail` | Chi tiết action |

---

## Gợi ý cho db-mapper

1. Tìm bảng bắt đầu bằng `form_answer` trong `db/index.md`
2. Kiểm tra cột `type` để xác định ENUM values cho シンプル/分岐
3. Kiểm tra cột `deleted_at` để xác nhận soft-delete pattern (90 ngày)
4. Tìm bảng liên kết với `friend_information_setting` (để ghi câu trả lời vào friend info)
5. Tìm bảng Google Sheets integration
6. Kiểm tra cột `slug` (6 ký tự random alphanumeric)
7. Chú ý: ID trong result URL (vd 124593) có thể là ID của bảng form, không phải result — cần xác nhận

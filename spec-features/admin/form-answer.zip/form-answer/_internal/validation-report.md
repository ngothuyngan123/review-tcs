# FA-011 — Validation Report: Tạo biểu mẫu「フォーム作成」

> Agent: spec-validator | Ngày tạo: 2026-05-21

---

## Tóm tắt

- **Kết luận**: ĐẠT (với lưu ý)
- **Số vấn đề**: 0 Nghiêm trọng, 5 Trung bình, 6 Nhẹ

---

## Kiểm tra từng spec

### 1. UI Spec

- [✓] **Đủ màn hình**: 10 màn hình được mô tả (SCR-FA11-01 đến SCR-FA11-10), bao gồm cả modal phụ (SCR-FA11-03-Modal). Bao phủ đầy đủ toàn bộ luồng từ danh sách, tạo mới, chỉnh sửa, xem kết quả đến khôi phục.
- [✓] **Đủ form fields**: Tất cả form fields được mô tả chi tiết — label JP, kiểu input, validation (độ dài tối đa), bắt buộc/tùy chọn.
- [✓] **Có user flows**: 5 user flows được mô tả rõ ràng + Flow Diagram Mermaid.
- [✓] **Mã SCR-FA11-XX nhất quán**: 10 màn hình được đánh số liên tục, không trùng lặp.
- [✓] **Mức độ tin cậy ghi rõ**: Mỗi thành phần UI ghi **Cao** / **Trung bình** / **Thấp**.
- [△] **Vùng chưa đủ**: 10 điểm chưa rõ được ghi nhận rõ ràng — điều này tốt nhưng cho thấy spec chưa hoàn chỉnh ở một số mục trong tab 各種設定, 診断コンテンツ, và luồng phân nhánh.

### 2. API Spec

- [✓] **Đủ endpoints**: 43 endpoints được mô tả (EP-01 đến EP-43), bao phủ toàn bộ CRUD, AJAX, form công khai, Google Sheets.
- [✓] **Request/response format rõ**: Các endpoint quan trọng (EP-04, EP-05, EP-15, EP-18, EP-25) đều có request params và response JSON format.
- [✓] **Validation rules có**: EP-04 ghi kiểm tra BackupHistory và free plan limit.
- [△] **Một số endpoint thiếu chi tiết**: EP-02, EP-03, EP-06 đến EP-13, EP-16, EP-17, EP-26 đến EP-43 chỉ có thông tin cơ bản (controller, file, middleware) nhưng thiếu request body chi tiết.
- [✓] **Auth middleware rõ**: Mỗi endpoint ghi rõ middleware (basic_access, is_expire, check_login, hoặc không cần auth).

### 3. Logic Spec

- [✓] **Controllers đầy đủ**: FormAnswerController được mô tả với đầy đủ 8 phương thức chính + dependencies.
- [✓] **Services có**: FormAnswerService và FormAnswerSettingCommonService được mô tả rõ.
- [✓] **Models có relationships**: 9 models được mô tả (FormAnswer, FormAnswerPage, FormAnswerDetails, FormAnswerResult, FormAnswerSetting, FormAnswerSettingCommon, FormAnswerFolder, FormAnswerPointSetting, FormAnswerUserAccept, FormAnswerItemRemind, FormAnswerConnectGoogle).
- [✓] **Business rules rõ**: 12 business rules được mô tả chi tiết (free plan limit, unique key, reply kind, bạn bè, ghi friend info, backup lock, soft delete, Google Sheets, using_old_version, 分岐タイプ, validation rules, link friend info).
- [✓] **Background job có**: AddResultFormAnswerToGoogleSpreadSheet được ghi nhận (kèm ghi chú đang bị comment out).

### 4. DB Mapping

- [✓] **Coverage >= 70%**: Ước tính 10/10 màn hình được map DB, toàn bộ primary tables (10 bảng) được document đầy đủ schema.
- [✓] **Primary tables xác định đúng**: `form_answer`, `form_answer_details`, `form_answer_page`, `form_answer_result`, `form_answer_setting`, `form_answer_setting_common`, `form_answer_folder`, `form_answer_user_accept`, `form_answer_item_remind`, `form_answer_point_setting`.
- [✓] **FKs documented**: Tất cả FK quan trọng được ghi rõ (bot_id, form_id, line_id, user_id_del, action_reply_id, action_open_id, diagnostic_friend_info_id, v.v.).
- [✓] **Enum values documented**: Bảng enum đầy đủ cho form_type, is_public, reply_kind, using_old_version, next_page_type, use_basic_diagnostic, status_sync_sheet, form_answer_connect_googles.status.
- [△] **Unmapped items**: 3 UI fields chưa tìm được DB match (「表示期限」, 「クイックテスト」 trạng thái, `count_reply` trong form_answer_user_accept) — đã được ghi nhận.
- [✓] **ER Diagram có**: Mermaid ER diagram đầy đủ tất cả primary và secondary tables.

---

## Kiểm tra chéo (Cross-check)

### UI ↔ API

| UI Action | Endpoint | Kết quả |
|-----------|----------|---------|
| Click「新規作成」→ modal → submit | EP-04 POST `/basic/form-answer/store-v3` | ✓ Match |
| Toggle「公開状態」 | EP-21 POST `/ajax/change-public-form-answer` | ✓ Match |
| Click「URLを表示」(配信用URL) | — | △ Không rõ endpoint cụ thể (có thể client-side từ data sẵn có) |
| Download CSV | EP-19 GET `/ajax/download-answer/{id}` | ✓ Match |
| Xem kết quả (「表示」) | EP-14/15 GET/POST `/basic/form-answer/v3/result/{id}` | ✓ Match |
| Thêm/xóa thư mục | EP-26/27 POST `/ajax/form-answer/create-folder` và `delete-folder` | ✓ Match |
| Chuyển thư mục (bulk) | EP-28 POST `/ajax/form-answer/move-folder` | ✓ Match |
| Xóa nhiều form (bulk) | EP-29 POST `/ajax/form-answer/delete-list-formanswer` | ✓ Match |
| Sắp xếp form | EP-30 POST `/ajax/sort-form-answer` | ✓ Match |
| Sắp xếp thư mục | EP-18 (action=sortFolder) | ✓ Match (trong EP-18) |
| Kiểm tra Google Sheets | EP-20 GET `/ajax/google-sheet-active` | ✓ Match |
| Lưu form (「保存」trong editor) | EP-05 POST `/basic/form-answer/save-v3/{id}` | ✓ Match |
| Lưu thiết kế chung | EP-09 POST `/basic/form-answer/{id}/save-setting-common` | ✓ Match |
| Lưu tin nhắn sau submit | EP-36 POST `/basic/form-answer/v3/saveMessageReply` | ✓ Match |
| Lưu cài đặt khác | EP-06 POST `/basic/form-answer/update-other-settings/{id}` | ✓ Match |
| Khôi phục form đã xóa | EP-32 POST `/ajax/restore-form-answer/{id}` | ✓ Match |
| Quick test | EP-41 POST `/basic/form-answer/quickSendForm` | ✓ Match |
| Submit form (LINE user) | EP-25 POST `/basic/form-answer/form-render-v3/store` | ✓ Match |
| Xem form công khai | EP-23 GET `/basic/form-answer/form-render-v3/{slug}` | ✓ Match |
| Xóa câu trả lời | — | △ Không tìm thấy endpoint DELETE answer trong API spec |
| Xem chi tiết 1 câu trả lời | EP-42 GET `/basic/form-answer/detail-result/{form_id}/{form_result_id}` | ✓ Match (endpoint tồn tại dù UI spec dùng inline panel) |

**Phát hiện**: Nút「この回答を削除」trong SCR-FA11-09 không có endpoint tương ứng rõ ràng trong API spec — EP-18 có `action=deleteItem` nhưng đó là xóa form, không phải xóa câu trả lời.

### API ↔ Logic

| Endpoint | Controller Method | Kết quả |
|----------|-----------------|---------|
| EP-01 GET `/basic/form-answer` | `index_v3()` line 184 | ✓ Match |
| EP-02 GET `/basic/form-answer/edit/{id}` | `editV3()` line 734 | ✓ Match |
| EP-04 POST `store-v3` | `storeV3()` line 6928 | ✓ Match |
| EP-05 POST `save-v3/{id}` | `saveV3()` line 1242 | ✓ Match |
| EP-06 POST `update-other-settings/{id}` | `updateOtherSettings()` line 7834 | ✓ Match |
| EP-07 POST `update-form-system/{id}` | `updateFormSystem()` line 7877 | ✓ Match |
| EP-09 POST `save-setting-common` | `saveSettingCommon()` line 914 | ✓ Match |
| EP-14/15 GET/POST `v3/result/{id}` | `showFormResultV3()` line 4534 | ✓ Match |
| EP-18 POST `ajax/get-list-form-answer-v3` | `ajaxGetFormAnswerListV3()` line 3462 | ✓ Match |
| EP-19 GET `ajax/download-answer/{id}` | `downloadViewer()` line 4099 | ✓ Match |
| EP-20 GET `ajax/google-sheet-active` | `googleSheetActive()` line 7184 | ✓ Match |
| EP-21 POST `ajax/change-public-form-answer` | `changePublicFormAnswer()` line 3612 | ✓ Match |
| EP-22/23 GET form-render | `renderForm()` / `renderFormV3()` | ✓ Match |
| EP-24/25 POST form-render/store | `storeRenderForm()` / `storeRenderFormV3()` | ✓ Match |
| EP-31 GET `get-form-answer-removed` | `getFormAnswerRemoved()` line 7307 | ✓ Match |
| EP-32 POST `restore-form-answer/{id}` | `restoreFormAnswer()` line 7328 | ✓ Match |
| EP-26 POST `create-folder` | `createFolder()` line 5665 | ✓ Match |
| EP-29 POST `delete-list-formanswer` | `deleteListFormanswer()` line 6793 | ✓ Match |
| EP-41 POST `quickSendForm` | `quickSendForm()` line 7221 | ✓ Match |

**Ghi chú**: EP-03, EP-08, EP-10, EP-11, EP-12, EP-13, EP-27, EP-28, EP-30, EP-33 đến EP-40, EP-42, EP-43 chỉ được liệt kê trong API spec với controller/file nhưng không có chi tiết phương thức trong logic spec. Tuy nhiên đây không phải vấn đề nghiêm trọng vì logic spec chỉ mô tả các phương thức chính quan trọng.

### Logic ↔ DB

| Model | DB Table | Kết quả |
|-------|----------|---------|
| `FormAnswer` | `form_answer` | ✓ Match — SoftDeletes, relationships xác nhận |
| `FormAnswerPage` | `form_answer_page` | ✓ Match — SoftDeletes, constants NEXT_PAGE_TYPE |
| `FormAnswerDetails` | `form_answer_details` | ✓ Match — SoftDeletes, tất cả trường quan trọng khớp |
| `FormAnswerResult` | `form_answer_result` | ✓ Match — SoftDeletes, trường `data` JSON |
| `FormAnswerSetting` | `form_answer_setting` | ✓ Match — upsert theo form_id |
| `FormAnswerSettingCommon` | `form_answer_setting_common` | ✓ Match — đầy đủ design fields |
| `FormAnswerFolder` | `form_answer_folder` | ✓ Match — SoftDeletes |
| `FormAnswerPointSetting` | `form_answer_point_setting` | ✓ Match — from_point, to_point, action_id |
| `FormAnswerUserAccept` | `form_answer_user_accept` | ✓ Match — SoftDeletes, is_update |
| `FormAnswerItemRemind` | `form_answer_item_remind` | ✓ Match — SoftDeletes, FK form_result_id |
| `FormAnswerConnectGoogle` | `form_answer_connect_googles` | △ Logic spec ghi `FormAnswerConnectGoogle` / tên bảng `form_answer_connect_google`, DB mapping ghi `form_answer_connect_googles` (có 's') — cần xác nhận tên bảng chính xác |

### DB-hint ↔ DB Mapping

| Hint Item | DB Match | Kết quả |
|-----------|----------|---------|
| `name` / `manage_name` (管理名) | `form_answer.name` | ✓ Khớp — hint dự đoán đúng |
| `form_type` enum (0=simple, 1=branch) | `form_answer.form_type` (1=シンプル, 2=分岐) | △ Giá trị lệch: hint dự đoán 0/1, thực tế là 1/2 |
| `is_public` (0/1) | `form_answer.is_public` | ✓ Khớp |
| `deleted_at` (soft-delete) | `form_answer.deleted_at` | ✓ Khớp |
| Slug 6 ký tự | `form_answer.unique_key` | ✓ Khớp |
| `reply_kind` (giới hạn trả lời) | `form_answer.reply_kind` (0/1/2) | ✓ Khớp |
| `folder_id` → FK | `form_answer.group_id` | △ Hint dự đoán tên `folder_id`, thực tế là `group_id` |
| `label` / `question` (質問文) | `form_answer_details.label` | ✓ Khớp |
| `is_required` | `form_answer_details.rules` (JSON `{"required":true}`) | △ Hint dự đoán cột riêng, thực tế lưu trong JSON `rules` |
| `description` (補足) | `form_answer_details.help` | △ Hint dự đoán `description`, thực tế là `help` |
| `sort_order` / `position` | `form_answer_details.position` | ✓ Khớp |
| `action_id` → t_actions | `form_answer.action_reply_id` | ✓ Khớp |
| `bg_color` (フォーム背景) | `form_answer_setting_common.bg_form` | △ Hint dự đoán `bg_color`, thực tế là `bg_form` |
| `display_from`, `display_until` (表示期限) | Không tìm thấy | △ Vẫn unmapped — hint dự đoán đúng rằng cần tìm nhưng DB mapping vẫn chưa tìm được |
| `submit_button_text` | `form_answer.button_submit_name` | △ Tên cột khác hint |
| `header_image` | `form_answer_setting_common.image_header` hoặc `form_answer_page.page_image` | ✓ Khớp (với ghi chú legacy trong form_answer.image_header) |

---

## Danh sách vấn đề

### Nghiêm trọng (blocking)

_Không có vấn đề nghiêm trọng._

---

### Trung bình

**1. Thiếu endpoint xóa câu trả lời đơn lẻ**

UI spec SCR-FA11-09 có nút「この回答を削除」nhưng API spec không ghi rõ endpoint tương ứng. EP-18 (`action=deleteItem`) chỉ xóa form, không phải xóa câu trả lời. EP-19 là download CSV.

Đề xuất: Tìm endpoint DELETE cho `form_answer_result` — có thể là một AJAX endpoint chưa được ghi vào API spec. Cần grep controller để tìm method xóa result (ví dụ `deleteResult`, `destroyResult`).

**2. Tên bảng không nhất quán: `form_answer_connect_google` vs `form_answer_connect_googles`**

- Logic spec model `FormAnswerConnectGoogle` với ghi chú table `form_answer_connect_google` (không có 's')
- DB mapping ghi primary table `form_answer_connect_googles` (có 's')
- DB mapping section secondary table ghi `form_answer_connect_googles`

Đề xuất: Kiểm tra schema thực tế trong `db/schema/tables/` để xác nhận tên bảng chính xác.

**3. `form_answer_user_accept` thiếu cột `count_reply`**

DB mapping ghi nhận "Cột `count_reply` trong `form_answer_user_accept` — Index DB ghi 8 cột nhưng schema chỉ thấy `is_update`". Logic spec Business Rule 3 mô tả `reply_kind=2` dùng `FormAnswerUserAccept` để theo dõi số lần trả lời — nhưng không có cột `count_reply` trong schema đã dump. Nếu thiếu cột này thì business rule 3 không thể hoạt động đúng.

Đề xuất: Đọc lại file `db/schema/tables/form_answer_user_accept.sql` để kiểm tra xem có cột `count_reply` không (có thể schema dump bị thiếu).

**4. Tab「友だち一覧」trong SCR-FA11-09 chưa được spec**

UI spec ghi nhận tab「友だち一覧」tồn tại trong trang kết quả nhưng chưa có mô tả nội dung (snapshot giống nhau). Không có endpoint tương ứng riêng cho tab này trong API spec.

Đề xuất: Thu thập thêm snapshot cho tab「友だち一覧」để hoàn chỉnh UI spec cho SCR-FA11-09.

**5. Tính năng「表示期限」chưa được map DB**

UI spec SCR-FA11-07 có mục「表示期限・カウントダウンタイマー」nhưng DB mapping không tìm được cột `display_from`/`display_until` trong schema. DB-hint cũng dự đoán 2 cột này nhưng không xác nhận được.

Đề xuất: Kiểm tra `form_answer` schema kỹ hơn — 「表示期限」có thể được lưu trong cột `setting_page_confirm` (JSON) hoặc có thể là tính năng chưa được implement trong DB hiện tại. Ghi mức độ tin cậy **Thấp** cho mapping này.

---

### Nhẹ

**1. Enum `form_type`: DB-hint dự đoán sai giá trị (0/1 thay vì 1/2)**

DB-hint dự đoán `0=simple, 1=branch`, nhưng thực tế DB dùng `1=シンプル, 2=分岐`. Không ảnh hưởng đến specs hoàn thiện nhưng nên update db-hint để nhất quán.

Đề xuất: Cập nhật db-hint.md phần SCR-FA11-01 enum values.

**2. DB-hint dùng tên cột khác thực tế ở một số chỗ**

- Hint dự đoán `folder_id`, thực tế là `group_id`
- Hint dự đoán `description` (補足), thực tế là `help`
- Hint dự đoán `bg_color`, thực tế là `bg_form`
- Hint dự đoán `submit_button_text`, thực tế là `button_submit_name`
- Hint dự đoán `is_required`, thực tế là JSON `rules.required`

Tất cả đã được giải quyết trong db-mapping.md với ghi chú phù hợp. Đây chỉ là vấn đề nhẹ vì db-hint là file nội bộ hỗ trợ.

**3. Logic spec không mô tả EP-03 (`common-design-setting/{id}`)**

EP-03 là trang riêng cho cài đặt thiết kế chung nhưng logic spec không có phương thức tương ứng. Có thể đây là alias/redirect về edit page với tab khác.

Đề xuất: Xác nhận xem EP-03 có phương thức controller riêng hay dùng chung với `editV3`.

**4. Logic spec không mô tả EP-08 (`update-settings-style/{id}`)**

EP-08 là endpoint cập nhật cài đặt giao diện nhưng không có phương thức tương ứng trong logic spec. Có thể là endpoint deprecated hoặc alias của EP-09.

Đề xuất: Grep controller để tìm `updateSettingsStyle` — nếu tồn tại thì cần bổ sung vào logic spec.

**5. API spec thiếu request body cho ~20 endpoints**

EP-02, EP-03, EP-10, EP-11, EP-12, EP-13, EP-27, EP-28, EP-30, EP-33 đến EP-40, EP-42, EP-43 chỉ có thông tin controller/file nhưng thiếu request/response format.

Đề xuất: Đây là vấn đề nhẹ vì các endpoints phụ ít critical hơn. Có thể bổ sung trong lần spec tiếp theo nếu cần.

**6. Form Answer `count_reply` trong model vs `form_answer_user_accept` schema**

Logic spec Business Rule 3 nói "kiểm tra qua `form_answer_result` count" cho `reply_kind=1` nhưng `FormAnswerUserAccept` (dùng cho `reply_kind=2`) có vẻ dùng `count_reply`. Sự phân biệt giữa 2 cơ chế cần được làm rõ hơn.

Đề xuất: Bổ sung vào logic spec Business Rule 3 rõ hơn: `reply_kind=1` → count từ `form_answer_result`, `reply_kind=2` → dùng `form_answer_user_accept.count_reply` (nếu cột tồn tại).

---

## Kiểm tra nhất quán thêm

### Validation rules UI ↔ Logic

| UI | Logic/DB | Kết quả |
|----|----------|---------|
| 管理名 tối đa 50 ký tự | `form_answer.name VARCHAR(255)` — không có DB constraint rõ | △ UI enforce 50 nhưng DB cho phép 255 — validation ở code layer |
| フォーム名 tối đa 20 ký tự | `form_answer.title VARCHAR(255)` — không có DB constraint rõ | △ Tương tự trên |
| Free plan giới hạn 3 form | Business Rule 1 — kiểm tra trong `storeV3()` và `restoreFormAnswer()` | ✓ Match |
| form_type không đổi sau khi tạo | Không thấy constraint DB — logic ở client-side | △ Cần xác nhận backend có enforce không |

### Error states UI ↔ Logic

| Error | Logic | Kết quả |
|-------|-------|---------|
| `"status": "false_friend"` | Business Rule 4 — user chưa là bạn bot | ✓ Match |
| `"status": "false_reply_kind"` | Business Rule 3 — đã trả lời | ✓ Match |
| Vượt giới hạn free plan | 500 response với error message | ✓ Match |
| Backup đang chạy | 500 response với `MESSAGE_NOTIFY_BACKUP` | ✓ Match |

---

## Kết luận

**ĐẠT**

FA-011 có bộ specs chất lượng tốt: UI spec đầy đủ 10 màn hình với user flows rõ ràng, API spec có 43 endpoints được liệt kê, logic spec mô tả đầy đủ business rules quan trọng, và DB mapping có coverage cao (>80%) với tất cả primary tables được document đầy đủ.

Các vấn đề phát hiện đều ở mức Trung bình hoặc Nhẹ, không có vấn đề Nghiêm trọng nào blocking việc sử dụng specs này cho phát triển. Điểm cần chú ý nhất là:

1. **Thiếu endpoint xóa câu trả lời** (vấn đề Trung bình 1) — cần bổ sung
2. **Tên bảng `form_answer_connect_google(s)`** cần xác nhận
3. **Cột `count_reply`** trong `form_answer_user_accept` cần xác nhận schema

Spec có thể tiến sang bước spec-compiler để tổng hợp `feature-spec.md`. Các vấn đề trên nên được ghi vào phần "Điểm chưa rõ" của feature-spec.md để theo dõi.
